package bountyboard.ui.menus;

public interface MenuStrategy {
    MenuStrategy execute();
    void displayMenu();
}
